create
    definer = root@localhost procedure reqSpecialite(IN surnom varchar(100),
                                                     OUT specialite enum ('Peinture', 'Sculpture', 'Collage'))
BEGIN
SELECT A.specialite INTO specialite FROM Artistes A WHERE A.surnom = surnom;



end;

