create
    definer = root@localhost function reqSpecialites(surnom varchar(100)) returns enum ('Peinture', 'Sculpture', 'Collage')
BEGIN
        DECLARE specialite enum('Peinture', 'Sculpture', 'Collage');

        SELECT A.specialite INTO specialite FROM Artistes A WHERE A.surnom = surnom;
        RETURN  specialite;
    end;

